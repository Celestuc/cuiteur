<?php

// chargement des bibliothèques de fonctions
require_once('bibli_cuiteur.php');
require_once('bibli_generale.php');

// bufferisation des sorties
ob_start();

$GLOBALS['bd'] = bdConnect();

affDebutMenuInfos('Reponses');

if (count($_GET) !== 1 || !isset($_GET['blID'])) {
    echo '<section>
            <h2>Oups, il y a eu une erreur...</h2>
            <p class="erreur">L\'URL n\'a pas la bonne forme. Il manque le paramètre "blID" ou il y a un paramètre en trop.</p>
          </section>';
} 
else {
    $blID = $_GET['blID'];

    if (!is_numeric($blID) || floor($blID) != $blID) {
        echo '<section>
                <h2>Oups, il y a eu une erreur...</h2>
                <p class="erreur">La valeur de "blID" n\'est pas un entier.</p>
              </section>';
    } 
    elseif ($blID <= 0) {
        echo '<section>
                <h2>Oups, il y a eu une erreur...</h2>
                <p class="erreur">La valeur de "blID" n\'est pas un entier strictement positif.</p>
              </section>';
    } 
    else {
        $blablaInitial = bdGetBlablas('initial', (int)$blID);

        if (empty($blablaInitial)) {
            echo '<section>
                    <h2>Oups, il y a eu une erreur...</h2>
                    <p class="erreur">Le blabla initial "' . htmlspecialchars($blID) . '" n\'existe pas.</p>
                  </section>';
        } 
        else {
            affBlablasInit($blablaInitial[0]);
            affFormPublier();

            $reponses = bdGetBlablas('reponses', (int)$blID);
            affBlablas($reponses);
        }
    }
}

affPiedFin();
ob_end_flush();

 